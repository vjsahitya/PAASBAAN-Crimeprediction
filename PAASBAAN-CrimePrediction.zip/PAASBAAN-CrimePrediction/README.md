# Crime classification, analysis & prediction in Indore city
# All the modules must be installed to run it.
# Just run App.py
# Everything you need to know is on Final_report.pdf
